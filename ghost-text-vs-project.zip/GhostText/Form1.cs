﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GhostText
{
    public partial class frmMain : Form
    {
        private bool dragging = false;
        private Point dragCursorPoint;
        private Point dragFormPoint;


        public frmMain()
        {
            InitializeComponent();
        }

        void vSaveText()
        {
            string filepath = AppDomain.CurrentDomain.BaseDirectory + @"\GhostText-" + DateTime.Now.Date.ToString("yyyy'-'MM'-'dd") + ".txt";

            using (StreamWriter sw = File.CreateText(filepath))
            {
                sw.WriteLine(richTextBox1.Text);
            }
        }

        void vReadText()
        {
            string filepath = AppDomain.CurrentDomain.BaseDirectory + "Ghost-Text-" + DateTime.Now.Date.ToString("yyyy'-'MM'-'dd") + ".txt";

            if (File.Exists(filepath))
            {
                using (StreamReader sr = new StreamReader(filepath))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        richTextBox1.Text += line + "\r\n";
                    }
                }
            }
        }
        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                dragging = true;
                dragCursorPoint = Cursor.Position;
                dragFormPoint = this.Location;
            }
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point dif = Point.Subtract(Cursor.Position, new Size(dragCursorPoint));
                this.Location = Point.Add(dragFormPoint, new Size(dif));
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            MatchCollection wordColl = Regex.Matches(richTextBox1.Text + " ", @"[\W]+");
            lblWords.Text = wordColl.Count.ToString();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            vSaveText();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            vSaveText();
        }

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            this.Opacity = Convert.ToDouble(trackBar1.Value) / 100;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            vReadText();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
    }
}
